import os
import onnxruntime as rt
import numpy as np
from PIL import Image

providers = ['CPUExecutionProvider']

def load_model():
    model_dir = os.path.dirname(__file__)
    model_path = os.path.join(model_dir, "model.onnx")
    if not os.path.exists(model_path):
        raise FileNotFoundError("No ONNX model found in directory.")
    else:
        m = rt.InferenceSession(model_path, providers=providers)
        return m

def _extract_batch(fp_list, source_path, model):
    # Initialize a list to store the preprocessed images
    img_data_list = []
    for fp in fp_list:
        img_path = os.path.join(source_path, fp)
        img = Image.open(img_path).resize((224, 224))
        img_array = np.array(img)
        img_array = np.expand_dims(img_array, axis=0).astype(np.float32)
        features = model.run(None, {'input': img_array})[0]
        img_data_list.append(features)

    return np.concatenate(img_data_list, axis=0)
